# HOMUS Dataset

This repository contains a revised version of the [HOMUS](http://grfia.dlsi.ua.es/homus/) with undesired artifacts removed from the data 
(e.g. strokes that the users made by accident and that do not belong to the symbol).